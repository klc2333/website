var searchData=
[
  ['checknames_0',['checkNames',['../orphanFinder_8cc.html#acb75a6a823a34584bd4504838ea23567',1,'orphanFinder.cc']]]
];
