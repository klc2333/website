var searchData=
[
  ['main_1',['main',['../orphanFinder_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'orphanFinder.cc']]]
];
