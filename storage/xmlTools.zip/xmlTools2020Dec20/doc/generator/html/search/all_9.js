var searchData=
[
  ['namepair_131',['namePair',['../classnamePair.html',1,'']]]
];
